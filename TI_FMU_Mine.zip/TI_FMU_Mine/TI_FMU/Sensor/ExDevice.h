#ifndef _EXDEVICE_H
#define _EXDEVICE_H

#include "include.h"

void ExDeviceHandle(void);

#endif
